# analysis.R
# Load the statistical functions
source("/home/ubuntu/Rallfun-v45.txt")

# Load required libraries
library(plotrix)
library(hrbrthemes)
library(reshape)
library(tidyverse)
library(viridis)
library(ragg)

Astig_Vector(dependent=T)     # For astigmatism vector data
